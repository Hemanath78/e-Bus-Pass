package com.example.ebuspass;

import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;

public class Home extends AppCompatActivity {
    NetworkChangeListner networkChangeListner = new NetworkChangeListner();

    FirebaseAuth mAuth;
Button btn1,btn2,btn3,btn4,btn5,btn6,btn7;
    String[] permission ={"android.permission.WRITE_EXTERNAL_STORAGE","android.permission.CAMERA"};

    @RequiresApi(api = Build.VERSION_CODES.M)

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
        mAuth = FirebaseAuth.getInstance();

        btn1 = findViewById(R.id.btn1);
        btn2 = findViewById(R.id.btn2);
        btn4 = findViewById(R.id.btn4);
        btn5 = findViewById(R.id.btn6);
        btn7 = findViewById(R.id.btn7);




    }

    public void onapplypass(View view) {
        Intent intent = new Intent(Home.this, ApplyPass.class);
        startActivity(intent);

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                requestPermissions(permission, 80);
            }

}


    public void onrenewal(View view){
        Intent intent = new Intent(Home.this, Renewal.class);
        startActivity(intent);
    }



    public void onchangepassword(View view){
        Intent intent = new Intent(Home.this, ChangePassword.class);
        startActivity(intent);
    }
    public void onabout(View view){
        Intent intent = new Intent(Home.this, AboutUs.class);
        startActivity(intent);
    }
    public void onhelp(View view){
        Intent intent = new Intent(Home.this, Help.class);
        startActivity(intent);
    }

    public void logout(View view) {
        mAuth.signOut();
        singOutUser();

    }

    private void singOutUser() {
        Intent intent = new Intent(Home.this, Login.class);
        startActivity(intent);
        finish();
    }



    //check for the permissions
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode==80){
            if(grantResults[0]== PackageManager.PERMISSION_GRANTED){
                Toast.makeText(this,"permissions allowed", Toast.LENGTH_SHORT).show();

            }else{
                Toast.makeText(this,"permissions denied", Toast.LENGTH_SHORT).show();
            }
        }
    }

    @Override
    protected void onStart() {

        IntentFilter filter = new IntentFilter(ConnectivityManager.CONNECTIVITY_ACTION);
        registerReceiver(networkChangeListner, filter);
        super.onStart();
    }

    @Override
    protected void onStop() {

        unregisterReceiver(networkChangeListner);
        super.onStop();
    }
}

