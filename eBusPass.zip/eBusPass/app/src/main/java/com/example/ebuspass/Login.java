package com.example.ebuspass;

import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.text.method.HideReturnsTransformationMethod;
import android.text.method.PasswordTransformationMethod;
import android.util.Patterns;
import android.view.View;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class Login extends AppCompatActivity {
    NetworkChangeListner networkChangeListner = new NetworkChangeListner();

    EditText editTextUserName, editTextPassword;
    TextView textViewForgotPassword, textViewRegister;
    ProgressBar progressBar;
    CheckBox showpassword;

    FirebaseAuth mAuth;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        editTextUserName = findViewById(R.id.user_email);
        editTextPassword = findViewById(R.id.user_password);
        textViewForgotPassword = findViewById(R.id.textforgotpassword);
        textViewRegister = findViewById(R.id.textregister);
        progressBar = findViewById(R.id.loginprogressbar);

        showpassword = findViewById(R.id.showpassword);

        showpassword.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if(b) {
                    editTextPassword.setTransformationMethod(HideReturnsTransformationMethod.getInstance());
                }
                else{
                    editTextPassword.setTransformationMethod(PasswordTransformationMethod.getInstance());
                }
            }
        });


        mAuth = FirebaseAuth.getInstance();




    }

    public void txtLoginForgotPasswordClicked(View view) {
        startActivity(new Intent(Login.this, ChangePassword.class));


    }

    public void txtRegisterClicked(View view) {
        startActivity(new Intent(Login.this, Register.class));


    }


    public void loginbtnclicked(View view) {

        String userName = editTextUserName.getText().toString().trim();
        String password = editTextPassword.getText().toString().trim();

        if(!Patterns.EMAIL_ADDRESS.matcher(userName).matches()){
            editTextUserName.setError("Please Enter Valid Email");
            editTextUserName.requestFocus();
        }

        if(editTextPassword.length() < 6){
            editTextPassword.setError("Please Enter Password containing atleast 6 characters");
            editTextPassword.requestFocus();
        }

        progressBar.setVisibility(View.VISIBLE);
        mAuth.signInWithEmailAndPassword(userName, password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {

              if(task.isSuccessful()){
                  progressBar.setVisibility(View.GONE);
                  Toast.makeText(Login.this, "User Has Successfully Logged in",Toast.LENGTH_LONG).show();

                  startActivity(new Intent(Login.this, Home.class));
                  finish();

              }
              else
              {
                  progressBar.setVisibility(View.GONE);
                  Toast.makeText(Login.this, "You entered email or password is wrong enter the details",Toast.LENGTH_LONG).show();
              }

            }


        });

    }
    @Override
    protected void onStart() {

        IntentFilter filter = new IntentFilter(ConnectivityManager.CONNECTIVITY_ACTION);
        registerReceiver(networkChangeListner, filter);
        super.onStart();
    }

    @Override
    protected void onStop() {

        unregisterReceiver(networkChangeListner);
        super.onStop();
    }



}