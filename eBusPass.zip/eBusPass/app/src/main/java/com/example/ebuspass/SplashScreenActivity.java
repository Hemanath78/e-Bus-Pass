package com.example.ebuspass;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkInfo;
import android.os.Build;
import android.os.Bundle;
import android.widget.Toast;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

import java.net.NetworkInterface;

@SuppressLint("CustomSplashScreen")
public class SplashScreenActivity extends AppCompatActivity {
    FirebaseAuth mAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash_screen);


        Thread timerthread = new Thread() {
            public void run() {
                try {
                    Thread.sleep(2000);

                } catch ( InterruptedException e ) {

                    e.printStackTrace();
                } finally {

                        mAuth = FirebaseAuth.getInstance();
                        FirebaseUser mFirebaseUser = mAuth.getCurrentUser();
                        if (mFirebaseUser != null) {
                            startActivity(new Intent(SplashScreenActivity.this, Home.class));
                            finish();
                        } else {
                            startActivity(new Intent(SplashScreenActivity.this, Login.class));
                            finish();
                        }

                    }
                    }





        };
        timerthread.start();

    }
}