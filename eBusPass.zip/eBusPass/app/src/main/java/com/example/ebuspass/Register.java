package com.example.ebuspass;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.IntentFilter;
import android.net.ConnectivityManager;
import android.os.Bundle;
import android.text.method.HideReturnsTransformationMethod;
import android.text.method.PasswordTransformationMethod;
import android.view.View;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.FirebaseDatabase;

public class Register extends AppCompatActivity {


    private FirebaseAuth mAuth;

    EditText editTextUserName;
    EditText editTextPassword;
    EditText editTextEmail;
    EditText editTextPhoneNo;
    ProgressBar progressBar;
    CheckBox showpasswordregister;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        mAuth = FirebaseAuth.getInstance();

        editTextUserName = findViewById(R.id.user_name);
        editTextPassword = findViewById(R.id.user_password);
        editTextEmail = findViewById(R.id.user_email);
        editTextPhoneNo = findViewById(R.id.user_mobile_no);
        progressBar = findViewById(R.id.registerprogressbar);
        showpasswordregister=findViewById(R.id.showpasswordreg);

        showpasswordregister.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean c) {
                if(c) {
                    editTextPassword.setTransformationMethod(HideReturnsTransformationMethod.getInstance());
                }
                else{
                    editTextPassword.setTransformationMethod(PasswordTransformationMethod.getInstance());
                }
            }
        });



    }

    public void registerbtnclicked(View v) {

        String txtUserName = editTextUserName.getText().toString().trim();
        String txtPassword = editTextPassword.getText().toString().trim();
        String txtEmail = editTextEmail.getText().toString().trim();
        String txtPhoneNo = editTextPhoneNo.getText().toString().trim();

        if (txtUserName.isEmpty()){
            editTextUserName.setError("Please enter UserName");
            editTextUserName.requestFocus();
        }

        if(txtPassword.isEmpty() || txtPassword.length() < 6){
            editTextPassword.setError("Please Enter Password containing atleast six characters");
            editTextPassword.requestFocus();
        }
        if (txtEmail.isEmpty()){
            editTextEmail.setError("Please Enter Valid email");
            editTextEmail.requestFocus();
        }

        if(txtPhoneNo.isEmpty() || txtPhoneNo.length() < 8){
            editTextPhoneNo.setError("Please Enter a Valid Mobile No");
        }
        progressBar.setVisibility(View.VISIBLE);

        mAuth.createUserWithEmailAndPassword(txtEmail, txtPassword).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {

                if(task.isSuccessful()){

                    User user = new User(txtUserName, txtPassword, txtEmail, txtPhoneNo);

                    FirebaseDatabase.getInstance().getReference("Users").child(FirebaseAuth.getInstance().getCurrentUser().getUid()).setValue(user).addOnCompleteListener(new OnCompleteListener<Void>() {
                        @Override
                        public void onComplete(@NonNull Task<Void> task) {

                            if(task.isSuccessful()){
                                Toast.makeText(Register.this,"User Registered Successfully",Toast.LENGTH_LONG).show();
                                progressBar.setVisibility(View.GONE);

                                Intent intent = new Intent(Register.this, Home.class);
                                startActivity(intent);


                            }

                            else {
                                Toast.makeText(Register.this, "User Failed to Register", Toast.LENGTH_LONG).show();
                                progressBar.setVisibility(View.GONE);
                            }


                        }
                    });



                }

                else {
                    Toast.makeText(Register.this, "User Failed to Register", Toast.LENGTH_LONG).show();
                    progressBar.setVisibility(View.GONE);
                }

            }
        });


    }

    public void txtloginhere(View v){
        Intent intent = new Intent(Register.this, Login.class);
        startActivity(intent);
    }


}