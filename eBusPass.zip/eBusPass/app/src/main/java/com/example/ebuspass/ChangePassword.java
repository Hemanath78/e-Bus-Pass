package com.example.ebuspass;

import static com.example.ebuspass.R.id;
import static com.example.ebuspass.R.layout;

import android.content.Intent;
import android.os.Bundle;
import android.util.Patterns;
import android.view.View;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;

public class ChangePassword extends AppCompatActivity {
    EditText editTextEmail;
    FirebaseAuth mAuth;
    ProgressBar progressBar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(layout.activity_change_password);
        editTextEmail= findViewById(id.email);
        progressBar = findViewById(id.progressBarchangepassword);
        mAuth = FirebaseAuth.getInstance();
    }

    public void forgotPasswordResetBtnPressed(View v){
        resetPassword();

    }
    private void resetPassword() {

        String txtEmail = editTextEmail.getText().toString().trim();

        if (!Patterns.EMAIL_ADDRESS.matcher(txtEmail).matches()){
            editTextEmail.setError("Please Enter Valid Email");
            editTextEmail.requestFocus();
            return;
        }
        progressBar.setVisibility(View.VISIBLE);

        mAuth.sendPasswordResetEmail(txtEmail).addOnCompleteListener(new OnCompleteListener<Void>() {
            @Override
            public void onComplete(@NonNull Task<Void> task) {
                if (task.isSuccessful()){
                    Toast.makeText(ChangePassword.this,"Please Check You Email to Reset Password" ,Toast.LENGTH_LONG).show();
                    Intent intent = new Intent(ChangePassword.this, Login.class);
                    startActivity(intent);
                    progressBar.setVisibility(View.GONE);
                }
                else {
                    Toast.makeText(ChangePassword.this,"Failed to Reset Password" ,Toast.LENGTH_LONG).show();
                }
            }
        });

    }

    public void changepasswordbackbtn(View view) {
        Intent intent = new Intent(ChangePassword.this, Home.class);
        startActivity(intent);
    }
}