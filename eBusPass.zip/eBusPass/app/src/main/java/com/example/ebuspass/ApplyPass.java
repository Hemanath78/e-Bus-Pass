package com.example.ebuspass;

import android.content.ClipData;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageSwitcher;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ViewSwitcher;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.io.IOException;
import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

public class ApplyPass extends AppCompatActivity {

    Button addproofs,previousimage,nextimage;
    ImageSwitcher imageshower;

    Button paymentpage;
    //passtypespinner declarations
    Spinner passtypespinner;
    List<String> passtypes;

    TextView startdate;

    TextView enddate;

    Spinner fromtospinner;
    Spinner showamount;

    private String selectedplace,selectedamount;



    //select image from gallery declarations
    int PICK_IMAGE_MULTIPLE = 3;
    String imageEncoded;
    TextView total;
    ArrayList<Uri> mArrayUri;
    int position = 0;
    List<String> imagesEncodedList;



    //passtype reference
    DatabaseReference databaseReference;

    private ArrayAdapter<CharSequence> fromtoAdapter, amountAdapter;





    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_apply_pass);

        //gallery selecting find by id's
        addproofs = findViewById(R.id.addproofs);
        previousimage = findViewById(R.id.previousimage);
        nextimage = findViewById(R.id.nextimage);
        imageshower = findViewById(R.id.imageshower);
        mArrayUri = new ArrayList<Uri>();

        //passtype elements
        passtypespinner= findViewById(R.id.passtypespinner);
        passtypes = new ArrayList<>();

        fromtospinner = findViewById(R.id.fromtospinner);
        showamount = findViewById(R.id.showamount);



        startdate = findViewById(R.id.startdate);

        enddate = findViewById(R.id.enddate);

        paymentpage = findViewById(R.id.paymentpage);

        Calendar calendar = Calendar.getInstance();
        String currentdate = DateFormat.getDateInstance().format(calendar.getTime());

        startdate.setText(currentdate);

        calendar.add(Calendar.DATE, 30);
        String nextdate = DateFormat.getDateInstance().format(calendar.getTime());

        enddate.setText(nextdate);

        paymentpage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ApplyPass.this, PaymentPage.class);
                startActivity(intent);
            }
        });





        databaseReference = FirebaseDatabase.getInstance().getReference();
        databaseReference.child("PassType").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                for(DataSnapshot childSnapshot:dataSnapshot.getChildren()) {

                    String spinnerName = childSnapshot.child("type").getValue(String.class);
                    passtypes.add(spinnerName);
                }
                ArrayAdapter<String> arrayAdapter = new ArrayAdapter<>(ApplyPass.this,R.layout.spinner_layout, passtypes);

                arrayAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

                passtypespinner.setAdapter(arrayAdapter);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

        fromtoAdapter = ArrayAdapter.createFromResource(this,R.array.array_fromto, R.layout.spinner_layout);

        fromtoAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        fromtospinner.setAdapter(fromtoAdapter);

        fromtospinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

                selectedplace = fromtospinner.getSelectedItem().toString();

                int parentID = parent.getId();
                if(parentID == R.id.fromtospinner)
                {
                    switch(selectedplace){
                        case "Select A place": amountAdapter = ArrayAdapter.createFromResource(parent.getContext(),
                                R.array.array_default_amount, R.layout.spinner_layout);
                            break;

                        case "Elampillai-Salem old Bus Stand-TPT": amountAdapter = ArrayAdapter.createFromResource(parent.getContext(),
                                R.array.array_elm_slm_tpt, R.layout.spinner_layout);
                            break;

                        case "Salem old Bus stand-New Bus stand-TPT": amountAdapter = ArrayAdapter.createFromResource(parent.getContext(),
                                R.array.array_slm_old_bus_new_bus_stnd_tpt, R.layout.spinner_layout);
                            break;

                        default:  break;

                    }
                    amountAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);     // Specify the layout to use when the list of choices appears
                    showamount.setAdapter(amountAdapter);


                    showamount.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                        @Override
                        public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                            selectedamount = showamount.getSelectedItem().toString();
                        }

                        @Override
                        public void onNothingSelected(AdapterView<?> parent) {

                        }
                    });
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });





        // showing all images in imageswitcher
        imageshower.setFactory(new ViewSwitcher.ViewFactory() {
            @Override
            public View makeView() {
                ImageView imageView1 = new ImageView(getApplicationContext());
                return imageView1;
            }
        });

        // click here to select next image
        nextimage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (position < mArrayUri.size() - 1) {
                    // increase the position by 1
                    position++;
                    imageshower.setImageURI(mArrayUri.get(position));
                } else {
                    Toast.makeText(ApplyPass.this, "Last Image Already Shown", Toast.LENGTH_SHORT).show();
                }
            }
        });

        // click here to view previous image
        previousimage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (position > 0) {
                    // decrease the position by 1
                    position--;
                    imageshower.setImageURI(mArrayUri.get(position));
                }
            }
        });

        // click here to select image
        addproofs.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                // initialising intent
                Intent intent = new Intent();

                // setting type to select to be image
                intent.setType("image/*");

                // allowing multiple image to be selected
                intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
                intent.setAction(Intent.ACTION_GET_CONTENT);
                startActivityForResult(Intent.createChooser(intent, "Select Picture"), PICK_IMAGE_MULTIPLE);
            }
        });


    }


    public void passbackbtn(View view) {
        Intent intent = new Intent(ApplyPass.this, Home.class);
        startActivity(intent);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        // When an Image is picked
        if (requestCode == PICK_IMAGE_MULTIPLE && resultCode == RESULT_OK && null != data) {
            // Get the Image from data
            if (data.getClipData() != null) {
                ClipData mClipData = data.getClipData();
                int cout = data.getClipData().getItemCount();
                for (int i = 0; i < 3; i++) {
                    // adding imageuri in array
                    Uri imageurl = data.getClipData().getItemAt(i).getUri();
                    mArrayUri.add(imageurl);
                }
                // setting 1st selected image into image switcher
                imageshower.setImageURI(mArrayUri.get(0));
                position = 0;
            } else {
                Uri imageurl = data.getData();
                mArrayUri.add(imageurl);
                imageshower.setImageURI(mArrayUri.get(0));
                position = 0;
            }
        } else {
            // show this if no image is selected
            Toast.makeText(this, "You haven't picked Image", Toast.LENGTH_LONG).show();
        }
    }




}
