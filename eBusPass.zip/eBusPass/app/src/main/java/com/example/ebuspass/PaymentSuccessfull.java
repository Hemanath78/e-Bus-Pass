package com.example.ebuspass;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class PaymentSuccessfull extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_payment_successfull);
    }
}