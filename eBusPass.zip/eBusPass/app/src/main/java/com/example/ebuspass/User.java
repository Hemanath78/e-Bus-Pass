package com.example.ebuspass;

public class User {

    public String userName;
    public String userPassword;
    public String email;
    public String phoneNo;

    public User(){

    }

    public User(String userName, String password, String email, String mobileNo){
        this.userName = userName;
        this.userPassword = password;
        this.email = email;
        this.phoneNo = mobileNo;
    }
}
